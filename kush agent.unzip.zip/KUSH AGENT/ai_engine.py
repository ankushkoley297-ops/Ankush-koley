from typing import Any
from openai import OpenAI
import streamlit as st


def get_ai_response(user_message, chat_history=None):
	api_key = st.secrets.get("OPENAI_API_KEY", "")

	if not api_key:
		return "Please add your OpenAI API Key in settings."

	client = OpenAI(api_key=api_key)
	messages: Any = [
		{
			"role": "system",
			"content": "You are KUSH AGENT, a helpful AI assistant. Reply in Bengali or English according to the user's language.",
		}
	]

	if chat_history:
		messages.extend(chat_history)

	messages.append({"role": "user", "content": user_message})

	try:
		response = client.chat.completions.create(
			model="gpt-4o-mini",
			messages=messages,
		)
		return response.choices[0].message.content
	except Exception as e:
		return f"AI Error: {e}"
