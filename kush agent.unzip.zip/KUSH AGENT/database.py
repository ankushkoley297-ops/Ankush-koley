import sqlite3

# Connect to database
def connect_db():
	conn = sqlite3.connect("kush_agent.db")
	return conn

# Create memory table
def create_table():
	conn = connect_db()
	cursor = conn.cursor()

	cursor.execute("""
		CREATE TABLE IF NOT EXISTS memory (
			id INTEGER PRIMARY KEY AUTOINCREMENT,
			user_message TEXT,
			ai_response TEXT
		)
	""")

	conn.commit()
	conn.close()

# Save conversation
def save_memory(user_message, ai_response):
	conn = connect_db()
	cursor = conn.cursor()

	cursor.execute(
		"INSERT INTO memory (user_message, ai_response) VALUES (?, ?)",
		(user_message, ai_response)
	)

	conn.commit()
	conn.close()

# Load conversation
def load_memory():
	conn = connect_db()
	cursor = conn.cursor()

	cursor.execute("SELECT * FROM memory")
	data = cursor.fetchall()

	conn.close()
	return data

# Create database table
create_table()
