"""
KUSH AGENT - Voice Assistant Module
-----------------------------------
বাংলা/ইংরেজি voice input এবং text-to-speech-এর জন্য একটি আলাদা module।

Install:
    python -m pip install SpeechRecognition pyttsx3 PyAudio

ব্যবহার:
    from voice import speak, listen_once, run_voice_assistant

    def handle_command(text):
        # এখানে ai_engine.py-এর সঙ্গে সংযোগ করবে
        return f"তুমি বলেছ: {text}"

    run_voice_assistant(handle_command)
"""

from __future__ import annotations

from typing import Callable, Optional

try:
    import speech_recognition as sr
except ImportError:
    sr = None

try:
    import pyttsx3
except ImportError:
    pyttsx3 = None


_engine = None


def _get_tts_engine():
    """একবারই TTS engine তৈরি করে পুনরায় ব্যবহার করে।"""
    global _engine

    if pyttsx3 is None:
        raise RuntimeError(
            "pyttsx3 ইনস্টল নেই। চালাও: python -m pip install pyttsx3"
        )

    if _engine is None:
        _engine = pyttsx3.init()
        _engine.setProperty("rate", 165)
        _engine.setProperty("volume", 1.0)

             # Windows-এ বাংলা voice থাকলে সেটি বেছে নেওয়ার চেষ্টা
    try:
        voices = _engine.getProperty("voices")

        if isinstance(voices, (list, tuple)):
            for voice in voices:
                details = f"{voice.id} {voice.name}".lower()

                if "bengali" in details or "bangla" in details or "bn" in details:
                    _engine.setProperty("voice", voice.id)
                    break

    except Exception:
        pass

    return _engine


def speak(text: str) -> None:
    """লেখাকে speaker দিয়ে শোনায়।"""
    if not text:
        return

    print(f"KUSH AGENT: {text}")

    try:
        engine = _get_tts_engine()
        engine.say(str(text))
        engine.runAndWait()
    except Exception as error:
        print(f"[TTS error] {error}")
        print("বাংলা voice না থাকলে Windows-এ Bengali speech voice যোগ করতে হতে পারে।")


def listen_once(
    language: str = "bn-IN",
    timeout: int = 5,
    phrase_time_limit: int = 12,
) -> Optional[str]:
    """মাইক্রোফোন থেকে একবার কথা শুনে text ফেরত দেয়।"""
    if sr is None:
        raise RuntimeError(
            "SpeechRecognition ইনস্টল নেই। চালাও: "
            "python -m pip install SpeechRecognition"
        )

    recognizer = sr.Recognizer()
    recognizer.pause_threshold = 0.8

    try:
        with sr.Microphone(device_index=1) as source:
            print("শুনছি... কথা বলো।")
            recognizer.adjust_for_ambient_noise(source, duration=0.6)
            audio = recognizer.listen(
                source,
                timeout=timeout,
                phrase_time_limit=phrase_time_limit,
            )

        print("কথা বুঝতে চেষ্টা করছি...")
        text = recognizer.recognize_google(audio, language=language)
        print(f"তুমি বলেছ: {text}")
        return text.strip()

    except sr.WaitTimeoutError:
        print("কোনো কথা শোনা যায়নি। আবার চেষ্টা করো।")
    except sr.UnknownValueError:
        print("কথাটি বুঝতে পারিনি। আরেকবার বলো।")
    except sr.RequestError as error:
        print(f"Speech service-এ সংযোগ করা যায়নি: {error}")
    except (OSError, AttributeError) as error:
        print(f"মাইক্রোফোন চালু করা যায়নি: {error}")
        print("PyAudio ইনস্টল আছে কি না এবং microphone permission পরীক্ষা করো।")

    return None


def run_voice_assistant(
    process_command: Optional[Callable[[str], str]] = None,
    language: str = "bn-IN",
) -> None:
    """
    Voice assistant loop চালায়।

    process_command:
        ব্যবহারকারীর কথাকে input হিসেবে নেয় এবং উত্তর (str) ফেরত দেয়।
        এখানে KUSH AGENT-এর ai_engine.py function যুক্ত করতে হবে।
    """
    speak("নমস্কার! KUSH AGENT voice assistant চালু হয়েছে।")

    while True:
        try:
            command = listen_once(language=language)

            if not command:
                continue

            normalized = command.lower().strip()

            if normalized in {
                "বন্ধ করো", "বন্ধ হও", "বের হও", "exit", "quit", "stop"
            }:
                speak("ঠিক আছে। KUSH AGENT বন্ধ হচ্ছে।")
                break

            if process_command is None:
                reply = f"তুমি বলেছ: {command}। AI engine এখনো যুক্ত করা হয়নি।"
            else:
                try:
                    reply = process_command(command)
                    if reply is None:
                        reply = "আমি এই মুহূর্তে উত্তর তৈরি করতে পারিনি।"
                except Exception as error:
                    print(f"[AI engine error] {error}")
                    reply = "দুঃখিত, উত্তর তৈরি করতে সমস্যা হয়েছে।"

            speak(str(reply))

        except KeyboardInterrupt:
            speak("KUSH AGENT বন্ধ করা হচ্ছে।")
            break
        except Exception as error:
            print(f"[Voice assistant error] {error}")
            speak("একটি সমস্যা হয়েছে। আবার চেষ্টা করো।")


if __name__ == "__main__":
    run_voice_assistant()
