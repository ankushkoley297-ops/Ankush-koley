import streamlit as st

st.set_page_config(
	page_title="Kush Agent",
	page_icon="📱",
	layout="centered"
)

st.title("📱 Kush Agent")
st.subheader("Login / লগইন")

# Language selection
language = st.selectbox(
	"Choose Language / ভাষা নির্বাচন করুন",
	["বাংলা", "English", "हिन्दी"]
)

# Mobile number
mobile = st.text_input(
	"Mobile Number",
	placeholder="Enter your mobile number"
)

# OTP
otp = st.text_input(
	"Enter OTP",
	placeholder="Enter 6-digit OTP",
	max_chars=6
)

# Login button
if st.button("Login / লগইন"):
	if len(mobile) == 10 and mobile.isdigit():
		if len(otp) == 6 and otp.isdigit():
			st.success("Login successful!")
			st.session_state["logged_in"] = True
			st.session_state["mobile"] = mobile
		else:
			st.error("Please enter a valid 6-digit OTP.")
	else:
		st.error("Please enter a valid 10-digit mobile number.")

# Dashboard
if st.session_state.get("logged_in", False):
	st.success("Welcome to Kush Agent!")
	st.write("Mobile:", st.session_state["mobile"])

	if st.button("Logout"):
		st.session_state["logged_in"] = False
		st.session_state.pop("mobile", None)
		st.rerun()
